Console.Write("Enter your name: ");
string studentName = Console.ReadLine() ?? "";

Console.Write("Enter your course: ");
string course = Console.ReadLine() ?? "";

Console.Write("Enter your year level: ");
int yearLevel = int.Parse(Console.ReadLine() ?? "0");

Console.Write("Enter quiz 1 score: ");
double quiz1 = double.Parse(Console.ReadLine() ?? "0");

Console.Write("Enter quiz 2 score: ");
double quiz2 = double.Parse(Console.ReadLine() ?? "0");

Console.Write("Enter quiz 3 score: ");
double quiz3 = double.Parse(Console.ReadLine() ?? "0");

decimal tuitionFee = 15000.00m;

double totalScore = quiz1 + quiz2 + quiz3;
double quizAverage = (quiz1 + quiz2 + quiz3) / 3;

bool isPassed = quizAverage >= 75;

Console.WriteLine();
Console.WriteLine("===== STUDENT PROFILE =====");
Console.WriteLine();
Console.WriteLine($"Name: {studentName}");
Console.WriteLine($"Course: {course}, Year {yearLevel}");
Console.WriteLine($"Total Score: {totalScore}");
Console.WriteLine($"Average: {quizAverage}");
Console.WriteLine($"Tuition Fee: {tuitionFee:F2}");
Console.WriteLine($"Passed: {isPassed}");
